package com.javap.ems.model;

public enum Category {
    SPORT,
    MUSIK,
    KUNST
}
